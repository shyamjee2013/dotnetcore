﻿using SwiggyWebApi.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SwiggyWebApi.RepositoryPattern
{
    public interface ICategoryRepository
    {
        List<Category> GetCategory();

        Category GetCategoryById(int id);

        bool SaveCategory(Category objCategory);

        bool DeleteCategory(int id);
    }
}

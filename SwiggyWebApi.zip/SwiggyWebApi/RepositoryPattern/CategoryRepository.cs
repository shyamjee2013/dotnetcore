﻿using SwiggyWebApi.Model;
using SwiggyWebApi.MyContextFile;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SwiggyWebApi.RepositoryPattern
{
    public class CategoryRepository : ICategoryRepository
    {
        SwiggyDbContext _objSwiggyDbContext;
        public CategoryRepository(SwiggyDbContext dbContext)
        {
            _objSwiggyDbContext = dbContext;
        }
        public List<Category> GetCategory()
        {
            List<Category>  listCategory = _objSwiggyDbContext.CategoryTbl.ToList();
            return listCategory;            
        }

        public Category GetCategoryById(int id)
        {
            Category categoryObj = _objSwiggyDbContext.CategoryTbl.Find(id);
            return categoryObj;
        }

        public bool SaveCategory(Category objCategory)
        {
            var catData = _objSwiggyDbContext.CategoryTbl.Find(objCategory.Id);
            catData.Name = objCategory.Name;
            _objSwiggyDbContext.SaveChanges();
            return true;
        }

        public bool DeleteCategory(int id)
        {
            var objCategory = _objSwiggyDbContext.CategoryTbl.Find(id);
            _objSwiggyDbContext.Remove(objCategory);
            _objSwiggyDbContext.SaveChanges();
            return true;
        }

    }
}

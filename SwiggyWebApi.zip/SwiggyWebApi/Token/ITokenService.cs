﻿using SwiggyWebApi.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApi.Models;

namespace SwiggyWebApi.Token
{
    public interface ITokenService
    {
        AuthenticateResponse Authenticate(UserLogin userLoginModel);
    }
}

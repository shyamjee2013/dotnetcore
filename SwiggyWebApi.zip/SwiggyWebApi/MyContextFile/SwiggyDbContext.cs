﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using SwiggyWebApi.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SwiggyWebApi.MyContextFile
{
    public class SwiggyDbContext : IdentityDbContext
    {
        public SwiggyDbContext(DbContextOptions<SwiggyDbContext> options)
            : base(options)
        {
        }
        public DbSet<Category> CategoryTbl { get; set; }
        public DbSet<UserLogin> UserLoginTbl { get; set; }
        public DbSet<SubCategory> SubCategoryTbl { get; set; }

    }
}

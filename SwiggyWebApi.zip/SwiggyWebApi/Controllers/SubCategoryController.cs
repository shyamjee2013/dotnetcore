﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SwiggyWebApi.Model;
using SwiggyWebApi.MyContextFile;
using SwiggyWebApi.RepositoryPattern_Generic;

namespace SwiggyWebApi.Controllers
{
   // [Route("api/[controller]")]
    [ApiController]
    public class SubCategoryController : ControllerBase
    {
        private IRepository<SubCategory> _subCategoryRepository;

        // Same Object we are passing in Constructor..why ?.
        public SubCategoryController(IRepository<SubCategory> subCategoryRepository)
        {
            _subCategoryRepository = subCategoryRepository;
        }

        [HttpGet]
        [Route("SubCategory/GetSubCategory")]
        public List<SubCategory> GetSubCategoryList()
        {
            List<SubCategory> objSubCategory = new List<SubCategory>();

            objSubCategory = _subCategoryRepository.Get();

            // How we achive this functionality in case of generic.
            //objSubCategory = _objSwiggyDbContext.SubCategoryTbl.Include(x => x.Category).ToList();


            return objSubCategory;
        }

        [HttpPost]
        [Route("SubCategory/SaveSubCategory")]
        public bool SaveSubCategory(SubCategory obj)
        {
            var result = _subCategoryRepository.Save(obj);
            return true;
        }
    }
}
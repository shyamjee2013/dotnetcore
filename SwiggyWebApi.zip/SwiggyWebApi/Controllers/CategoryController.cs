﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing;
using SwiggyWebApi.Model;
using SwiggyWebApi.MyContextFile;
using SwiggyWebApi.RepositoryPattern;

namespace SwiggyWebApi.Controllers
{
    //[Route("[controller]")]
    [ApiController]
    public class CategoryController : ControllerBase
    {        
        ICategoryRepository _categoryRepository;
        public CategoryController(ICategoryRepository objCategoryRepository)
        {
            // Repository Pattern in .NetCore.
            _categoryRepository = objCategoryRepository;
        }

        [HttpGet]
        [Route("Category/GetCategory")]
        public List<Category> GetCategoryList()
        {
            List<Category> result = _categoryRepository.GetCategory();
            return result;
        }

        [HttpGet]
        [Route("Category/GetCategoryById/{id}")]
        public Category GetCategoryById(int id)
        {
            Category objCategory = _categoryRepository.GetCategoryById(id);
            return objCategory;
        }

        [HttpPost]
        [Route("Category/SaveCategoryById")]
        public bool SaveCategory([FromBody] Category objCategory)
        {
            try
            {
                var result = _categoryRepository.SaveCategory(objCategory);
                return true;
            }
            catch(Exception ex)
            {
                return false;
            }            
        }

        [HttpDelete]
        [Route("Category/DeleteCategoryById")]
        public bool DeleteCategoryById(int id)
        {
            try
            {
                bool result = _categoryRepository.DeleteCategory(id);
                return result;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }
}
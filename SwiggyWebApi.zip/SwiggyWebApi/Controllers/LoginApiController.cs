﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using SwiggyWebApi.Helpers;
using SwiggyWebApi.Model;
using SwiggyWebApi.RepositoryPattern_Generic;
using SwiggyWebApi.Token;
using WebApi.Models;

namespace SwiggyWebApi.Controllers
{
    //[Route("api/[controller]")]
    [ApiController]
    public class LoginApiController : ControllerBase
    {

        private IRepository<UserLogin> _userLoginRepository;        
        private ITokenService _tokenService;
        public LoginApiController(IRepository<UserLogin> userLoginRepository, ITokenService tokenService)
        {
            _userLoginRepository = userLoginRepository;            
            _tokenService = tokenService;
        }

        [HttpPost]
        [Route("LoginApi/CheckUser")]
        public IActionResult CheckUser([FromBody] UserLogin userLoginObj)
        {
            try
            {
                //bool boolResult = _userLoginRepository.ValidateUser(userLoginObj);
                //return boolResult;

                // return null if user not found
                if (userLoginObj.UserEmail == "core@gmail.com" && userLoginObj.UserPassword == "core")
                {
                    var response = _tokenService.Authenticate(userLoginObj);

                    if (response == null)
                    {
                        return BadRequest(new { message = "Username or password is incorrect" });
                    }                        
                    else
                    {
                        return Ok(response);
                    }                                       
                }
                else
                {
                    // user not found.
                    return BadRequest(new { message = "Username or password is incorrect" });
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
       
    }
}
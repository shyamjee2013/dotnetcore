﻿using Microsoft.EntityFrameworkCore;
using SwiggyWebApi.MyContextFile;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SwiggyWebApi.RepositoryPattern_Generic
{
    public class Repository<T> : IRepository<T> where T : class
    {
        private SwiggyDbContext _swiggyDbContext;
        private DbSet<T> _dbSet;
        public Repository(SwiggyDbContext swiggyDb)
        {
            _swiggyDbContext = swiggyDb;

            // Implementing Generic Logic.
            _dbSet = _swiggyDbContext.Set<T>();
        }

        public bool Delete(int id)
        {
            //throw new NotImplementedException();
            //Category---id=101

            T obj = _dbSet.Find(id);
            _dbSet.Remove(obj);
            // dbset.savechanges.

            return false;
        }

        public List<T> Get()
        {
            // How we achive this functionality in case of generic.
            //current
            //objSubCategory = _objSwiggyDbContext.T.Include(x => x.T22).ToList();

            List<T> result = _dbSet.ToList();
            return result;
        }
              

        public T GetById(int id)
        {
            throw new NotImplementedException();
        }

        public bool Save(T entity)
        {
            try
            {
                _dbSet.Add(entity);
                _swiggyDbContext.SaveChanges();
                return true;
            }
            catch(Exception ex)
            {
                throw ex;
            }            
        }

        public bool Update(T entity)
        {
            throw new NotImplementedException();
        }

        // How we make this method to generic ?
        public bool ValidateUser(T entity)
        {
           // var objT = _dbSet.wh

            
            // How to make this condition at runtime.
            // how we give column name dynamic at runtime.
            
            //var res = _dbSet.Where(x=>x.Equals(entity.useremail && entity.password))

           // if (objUser.UserEmail == "core@gmail.com" && objUser.UserPassword == "core")

            return true;
        }
    }
}

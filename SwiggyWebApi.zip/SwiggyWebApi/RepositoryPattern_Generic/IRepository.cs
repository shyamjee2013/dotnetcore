﻿using SwiggyWebApi.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SwiggyWebApi.RepositoryPattern_Generic
{
    public interface IRepository<T> where T: class
    {   
        List<T> Get();        
        //IEnumerable<T> GetAll();       


        T GetById(int id);        
        bool Save(T entity);
        bool Update(T entity);
        bool Delete(int id);

        bool ValidateUser(T entity);
    }
}
